from fastapi import APIRouter, HTTPException
from core.asset.schemas import AssetCreate, AssetRead, AssetTransition
from core.shared.enums import LifecycleStatus

router = APIRouter()

_ASSETS: dict[str, AssetRead] = {}


@router.post("", response_model=AssetRead)
def create_asset(payload: AssetCreate) -> AssetRead:
    if payload.asset_id in _ASSETS:
        raise HTTPException(status_code=409, detail="asset_id already exists")
    asset = AssetRead(**payload.model_dump())
    _ASSETS[payload.asset_id] = asset
    return asset


@router.get("/{asset_id}", response_model=AssetRead)
def get_asset(asset_id: str) -> AssetRead:
    asset = _ASSETS.get(asset_id)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    return asset


@router.post("/{asset_id}/transition", response_model=AssetRead)
def transition_asset(asset_id: str, payload: AssetTransition) -> AssetRead:
    asset = _ASSETS.get(asset_id)
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    if asset.lifecycle_status == LifecycleStatus.candidate and payload.target_status == LifecycleStatus.certified:
        raise HTTPException(status_code=400, detail="Invalid transition candidate -> certified")
    updated = asset.model_copy(update={"lifecycle_status": payload.target_status})
    _ASSETS[asset_id] = updated
    return updated
