from pydantic import BaseModel, Field
from core.shared.enums import AssetType, LifecycleStatus, CertificationStatus


class AssetCreate(BaseModel):
    asset_id: str = Field(..., examples=["AST-GR003"])
    gold_reference_id: str | None = Field(None, examples=["GR003"])
    name: str
    ticker: str | None = None
    exchange: str | None = None
    asset_type: AssetType
    sector: str | None = None
    industry: str | None = None
    country: str | None = None
    currency: str | None = None
    framework_version: str = "A-ZION v2.0"


class AssetRead(AssetCreate):
    lifecycle_status: LifecycleStatus = LifecycleStatus.candidate
    certification_status: CertificationStatus = CertificationStatus.not_started
    current_version: str = "1.0"


class AssetTransition(BaseModel):
    target_status: LifecycleStatus
    reason: str
