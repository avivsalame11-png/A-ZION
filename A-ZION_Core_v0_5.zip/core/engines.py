
def business_score(snapshot):
    return 95 if snapshot.get("status")=="OK" else None

def financial_score(snapshot):
    return 90 if snapshot.get("status")=="OK" else None

def valuation_score(snapshot):
    return None

def risk_score(snapshot):
    return 20 if snapshot.get("status")=="OK" else None

def final_score(snapshot):
    b=business_score(snapshot)
    f=financial_score(snapshot)
    if b is None or f is None:
        return {"status":"WAITING_FOR_DATA"}
    return {
        "business":b,
        "financial":f,
        "valuation":"Pending Live Data",
        "risk":20,
        "overall":round((b+f)/2,1),
        "status":"PRELIMINARY"
    }
