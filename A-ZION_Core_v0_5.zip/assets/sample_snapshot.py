
SNAPSHOT={
'status':'OK',
'ticker':'MSFT',
'close':557.0,
'volume':31000000
}
