# A-ZION Core v0.5 - Sprint 013

Adds the first executable scoring engines.

Run:
    python app.py
